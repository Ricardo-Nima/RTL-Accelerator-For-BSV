bsvbuild.sh -vs Hello.bsv

bsc -sim -g mkTb -u Hello.bsv

bsc -sim -e mkTb -o sim.out