// Types
#ifndef __ZJ_TYPES__
#define __ZJ_TYPES__
#include <vector>
#include <stdint.h>

namespace zj_core {
  struct Change {
    uint64_t at;
    uint64_t val;
    Change(int i1, int i2): at(i1), val(i2){}
  };
  typedef std::vector<Change> ChangeLists;
  typedef uint64_t Time;
}
#endif