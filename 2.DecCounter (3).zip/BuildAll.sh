#! /bin/sh

rm -rf ./zjout
./get_module_info

cd zjout && bsvbuild.sh -bs Hello.bsvbuild
bsvbuild.sh -vs Hello.bsv

./change_cxx
