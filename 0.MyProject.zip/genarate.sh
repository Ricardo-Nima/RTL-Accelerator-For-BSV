bsc -sim -g mkTb -u hello.bsv

bsc -sim -e mkTb -o sim.out